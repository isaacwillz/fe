
function submitExternal(){
	var pluginURL = jQuery(".smartcms_plugin_url").val();
	var userId = jQuery(".smartcms_user_id").val();
	var proType = jQuery("#scwaff_protype").find(".filter.active").text();
	var siteUrl = jQuery(".smartcms_site_url").val();
	
	var proName = jQuery("#scwaff_proname").val(),
		proShortDes = jQuery("#scwaff_proshortdes").val(),
		proDes = CKEDITOR.instances['scwaff_prodes'].getData();
	
	var proCats = "";
	jQuery(".product_category").each(function(){
		var elthis = jQuery(this);
		if( elthis.children("input").is(":checked") ){
			var thisVal = elthis.children("input").val();
			if(proCats)
				proCats += ","+thisVal;
			else
				proCats += thisVal;
		}
	});
	
	var proTags = jQuery("#scwaff_protags").val(),
		proVisible = jQuery("input[name='scwaff_provisible']:checked").val(),
		proFeatured = jQuery("#scwaff_profeatured").is(":checked")? "yes" : "no",
		proUrl = jQuery("#scwaff_producturl").val(),
		buttonText = jQuery("#scwaff_buttontext").val(),
		proRegularPrice = jQuery("#scwaff_regularprice").val(),
		proSalePrice = jQuery("#scwaff_saleprice").val(),
		proSalePriceDateFrom = jQuery("#scwaff_salepricedatefrom").val(),
		proSalePriceDateTo = jQuery("#scwaff_salepricedateto").val(),
		proTaxStatus = jQuery("#scwaff_taxstatus").val(),
		proTaxClass = jQuery("#scwaff_taxclass").val(),
		proSku = jQuery("#scwaff_prosku").val(),
		proUpsells = jQuery("#scwaff_upsells").val(),
		proCrosssells = jQuery("#scwaff_crosssells").val();
	
	var proAttrs = "";
	var numberAttrs = 0;
	jQuery("#scwaff_attributes").children("div").each(function(){
		var elthis = jQuery(this);
		if( elthis.children("select").size() > 0 ){
			var thisVal = "select#"+elthis.children("select").val();
			if(proAttrs)
				proAttrs += "@"+thisVal;
			else
				proAttrs += thisVal;
			
			if(elthis.children("select").val() && elthis.children("select").val() != "") numberAttrs++;
		}else{
			var thisVal = elthis.children("input").val();
			var thisId = elthis.children("input").attr("data-attrid");
			if(proAttrs)
				proAttrs += "@"+"text#"+thisId+"-"+thisVal;
			else
				proAttrs += "text#"+thisId+"-"+thisVal;
			
			if(thisVal) numberAttrs++;
		}
	});
	
	var proPurchaseNote = jQuery("#scwaff_pronote").val(),
		proMenuOrder = jQuery("#scwaff_promenuorder").val(),
		proEnableReviews = jQuery("#scwaff_proenablereview").is(":checked")? "yes" : "no",
		proCommission = jQuery("#scwaff_procommission").val(),
		proImage = jQuery(".scwaff_images_content_feature_preview > img").attr("src");
		
	var proGallery = "";
	jQuery(".scwaff_images_content_gallery_preview_item").each(function(){
		var elthis = jQuery(this);
		var src = elthis.find("img").attr("src");
		if(proGallery)
			proGallery += "@"+src;
		else
			proGallery += src;
	});
	
	jQuery.ajax({
		url: pluginURL+"helpers/submitExternal.php",
		data: {
			userId: userId,
			proType: proType,
			siteUrl: siteUrl,
			proName: proName,
			proShortDes: proShortDes,
			proDes: proDes,
			proCats: proCats,
			proTags: proTags,
			proVisible: proVisible,
			proFeatured: proFeatured,
			proUrl: proUrl,
			buttonText: buttonText,
			proRegularPrice: proRegularPrice,
			proSalePrice: proSalePrice,
			proSalePriceDateFrom: proSalePriceDateFrom,
			proSalePriceDateTo: proSalePriceDateTo,
			proTaxStatus: proTaxStatus,
			proTaxClass: proTaxClass,
			proSku: proSku,
			proUpsells: proUpsells,
			proCrosssells: proCrosssells,
			proAttrs: proAttrs,
			numberAttrs: numberAttrs,
			proPurchaseNote: proPurchaseNote,
			proMenuOrder: proMenuOrder,
			proEnableReviews: proEnableReviews,
			proCommission: proCommission,
			proImage: proImage,
			proGallery: proGallery
		},
		type: 'POST',
		beforeSend: function(e){
			jQuery(".smartcms_scwaff").css("opacity", "0.5");
			jQuery(".scwaff_ajax_loading").show();
		},
		success: function(data){
			jQuery(".smartcms_scwaff").css("opacity", "1");
			jQuery(".scwaff_ajax_loading").hide();
			
			jQuery(".scwaff_ajax_loading_done").slideDown();
			setTimeout(function(){ jQuery(".scwaff_ajax_loading_done").slideUp(); }, 3000);
		}
	});
}