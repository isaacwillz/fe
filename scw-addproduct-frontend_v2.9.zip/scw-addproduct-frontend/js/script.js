
jQuery(document).ready(function(){
	"use strict";
	initSample();

	var filterList = {
		init: function () {
			jQuery('.scwaff_prodata').mixItUp({
				selectors:{
					target: '.scwaff_prodata_item',
					filter: '.filter'	
				},
				animation: {
					enable: false
				},
				load: {
					filter: '.scwaff_protype_simple'
				}     
			});
		}
	};
	filterList.init();
	
	jQuery(".scwaff_prodata_content_left").children("div").each(function(){
		var elthis = jQuery(this);
		elthis.on("click", function(){
			var data = elthis.attr("scwaff-data");
			jQuery(".scwaff_prodata_content_right_item").slideUp();
			jQuery("#scwaff_"+data).slideDown();
			
			jQuery(".scwaff_prodata_content_left").children("div").removeClass("active");
			elthis.addClass("active");
		});
	});
	
	/////////////
	jQuery("#scwaff_protype li").each(function(){
		var elthis = jQuery(this);
		elthis.on("click", function(){
			var checkVal = elthis.children("span").text();
			if(checkVal != "Simple product"){
				jQuery(".scwaff_prodata_item_downloadablefiles").slideUp();
				jQuery(".scwaff_prodata_item_downloadlimit").slideUp();
				jQuery(".scwaff_prodata_item_downloadexpiry").slideUp();
			}else{
				if( jQuery("#scwaff_downloadable").is(":checked") ){
					jQuery(".scwaff_prodata_item_downloadablefiles").slideDown();
					jQuery(".scwaff_prodata_item_downloadlimit").slideDown();
					jQuery(".scwaff_prodata_item_downloadexpiry").slideDown();
				}
				else{
					jQuery(".scwaff_prodata_item_downloadablefiles").slideUp();
					jQuery(".scwaff_prodata_item_downloadlimit").slideUp();
					jQuery(".scwaff_prodata_item_downloadexpiry").slideUp();
				}
			}
			
			if(checkVal == "Bookable product"){
				if( jQuery("#scwaff_haspersons").is(":checked") )
					jQuery(".scwaff_prodata_persons").slideDown();
				else
					jQuery(".scwaff_prodata_persons").slideUp();
				
				if( jQuery("#scwaff_resources").is(":checked") )
					jQuery(".scwaff_prodata_resources").slideDown();
				else
					jQuery(".scwaff_prodata_resources").slideUp();
			}else{
				jQuery(".scwaff_prodata_resources").slideUp();
				jQuery(".scwaff_prodata_persons").slideUp();
			}
		});
	});
	
	jQuery("#scwaff_downloadable").change(function(){
		if( jQuery(this).is(":checked") ){
			jQuery(".scwaff_prodata_item_downloadablefiles").slideDown();
			jQuery(".scwaff_prodata_item_downloadlimit").slideDown();
			jQuery(".scwaff_prodata_item_downloadexpiry").slideDown();
		}
		else{
			jQuery(".scwaff_prodata_item_downloadablefiles").slideUp();
			jQuery(".scwaff_prodata_item_downloadlimit").slideUp();
			jQuery(".scwaff_prodata_item_downloadexpiry").slideUp();
		}
	});
	if( jQuery("#scwaff_downloadable").is(":checked") ){
		jQuery(".scwaff_prodata_item_downloadablefiles").slideDown();
		jQuery(".scwaff_prodata_item_downloadlimit").slideDown();
		jQuery(".scwaff_prodata_item_downloadexpiry").slideDown();
	}
	else{
		jQuery(".scwaff_prodata_item_downloadablefiles").slideUp();
		jQuery(".scwaff_prodata_item_downloadlimit").slideUp();
		jQuery(".scwaff_prodata_item_downloadexpiry").slideUp();
	}
	
	///////////////////
	jQuery(".scwaff_downloadablefiles_add").on("click", function(){
		var item = jQuery(".scwaff_downloadablefiles_content_item:eq(0)").clone();
		jQuery(".scwaff_downloadablefiles_content").append(item);
		jQuery(".scwaff_downloadablefiles_content_item").each(function(){
			var elthis = jQuery(this);
			elthis.find("i").on("click", function(){
				elthis.remove();
			});
		});
		
		jQuery( '.scwaff_downloadablefiles_content_item' ).each(function(){
			var elthis = jQuery(this);
			var file_frame;
			
			elthis.children( '.scwaff_downloadablefiles_content_button' ).on( 'click', function( event ) {
				event.preventDefault();
				if ( file_frame ) {
					file_frame.open();
					return;
				}
				file_frame = wp.media.frames.file_frame = wp.media({
					title: jQuery( this ).data( 'uploader_title' ),
					button: {
						text: jQuery( this ).data( 'uploader_button_text' ),
					}
				});

				file_frame.on( 'select', function() {
					attachment = file_frame.state().get('selection').first().toJSON();
					elthis.children( '.scwaff_downloadablefiles_content_url' ).val(attachment.url);
				});

				file_frame.open();
			});
		});
	});
	jQuery(".scwaff_downloadablefiles_content_item").each(function(){
		var elthis = jQuery(this);
		elthis.find("i").on("click", function(){
			elthis.remove();
		});
	});
	
	jQuery( '.scwaff_downloadablefiles_content_item' ).each(function(){
		var elthis = jQuery(this);
		var file_frame;
		
		elthis.children( '.scwaff_downloadablefiles_content_button' ).on( 'click', function( event ) {
			event.preventDefault();
			if ( file_frame ) {
				file_frame.open();
				return;
			}
			file_frame = wp.media.frames.file_frame = wp.media({
				title: jQuery( this ).data( 'uploader_title' ),
				button: {
					text: jQuery( this ).data( 'uploader_button_text' ),
				}
			});

			file_frame.on( 'select', function() {
				attachment = file_frame.state().get('selection').first().toJSON();
				elthis.children( '.scwaff_downloadablefiles_content_url' ).val(attachment.url);
			});

			file_frame.open();
		});
	});
	
	//////////////////////
	jQuery("#scwaff_salepricedatefrom, #scwaff_salepricedateto").datepicker({
		dateFormat : "yy-mm-dd"
	});
	
	/////////////////
	jQuery("#scwaff_haspersons").change(function(){
		if( jQuery(this).is(":checked") )
			jQuery(".scwaff_prodata_persons").slideDown();
		else
			jQuery(".scwaff_prodata_persons").slideUp();
	});
	jQuery("#scwaff_resources").change(function(){
		if( jQuery(this).is(":checked") )
			jQuery(".scwaff_prodata_resources").slideDown();
		else
			jQuery(".scwaff_prodata_resources").slideUp();
	});
	
	////////////////////////
	jQuery(".scwaff_upsells_span a, .scwaff_crosssells_span a, .scwaff_groupedproducts_span a").colorbox({
		inline:true,
		width:"50%",
		height: "300px",
		onOpen: function(){
			var elthis = jQuery(this);
			jQuery(".scwaff_chooseproducts").removeClass("scwaff_chooseproductsactive");
			elthis.parents(".scwaff_chooseproducts").addClass("scwaff_chooseproductsactive");
			
			jQuery(".scwaff_chooose_products_add").on("click", function(){
				var proids = "";
				jQuery(".scwaff_chooose_products_content_item").each(function(){
					if( jQuery(this).find("input").is(":checked") ){
						var thisVal = jQuery(this).find("input").val();
						if(proids)
							proids += ","+thisVal;
						else
							proids += thisVal;
					}
				});
				jQuery(".scwaff_chooseproductsactive").children("input").val(proids);
				jQuery.colorbox.close();
			});
		}
	});
	
	var pluginURL = jQuery(".smartcms_plugin_url").val();
	jQuery("#scwaff_chooose_products_header").keyup(function(){
		var keyword = jQuery(this).val();
		if(keyword.length >= 3){
			jQuery.ajax({
				url: pluginURL+"helpers/helper.php",
				data: {
					keyword: keyword,
					task: "getproducts"
				},
				type: 'POST',
				beforeSend: function(e){
					jQuery(".scwaff_chooose_products_header").css("opacity", "0.5");
				},
				success: function(data){
					jQuery(".scwaff_chooose_products_header").css("opacity", "1");
					if(data.length > 0){
						jQuery.each(data, function(key, val){
							jQuery(".scwaff_chooose_products_content").append("<div class='scwaff_chooose_products_content_item'>"+
								"<span class='scwaff_cpci_proid'><input type='checkbox' value='"+val.ID+"'></span>"+
								"<span class='scwaff_cpci_proname'>"+val.post_title+"</span>"+
							"</div>");
						});
					}
				},
				dataType: "json"
			});
		}
	});
	
	//////////////////
	jQuery(".scwaff_probookingrange_content_item").each(function(){
		var elthis = jQuery(this);
		elthis.find(".scwaff_probookingrange_content_item_type_select").change(function(){
			var thisVal = jQuery(this).val();
			if(thisVal == "custom"){
				elthis.find(".scwaff_probookingrange_content_item_from_custom, .scwaff_probookingrange_content_item_to_custom").slideDown();
				elthis.find(".scwaff_probookingrange_content_item_from_months, .scwaff_probookingrange_content_item_to_months").slideUp();
				elthis.find(".scwaff_probookingrange_content_item_from_weeks, .scwaff_probookingrange_content_item_to_weeks").slideUp();
				elthis.find(".scwaff_probookingrange_content_item_from_days, .scwaff_probookingrange_content_item_to_days").slideUp();
				elthis.find(".scwaff_probookingrange_content_item_from_time, .scwaff_probookingrange_content_item_to_time").slideUp();
			}else if(thisVal == "months"){
				elthis.find(".scwaff_probookingrange_content_item_from_custom, .scwaff_probookingrange_content_item_to_custom").slideUp();
				elthis.find(".scwaff_probookingrange_content_item_from_months, .scwaff_probookingrange_content_item_to_months").slideDown();
				elthis.find(".scwaff_probookingrange_content_item_from_weeks, .scwaff_probookingrange_content_item_to_weeks").slideUp();
				elthis.find(".scwaff_probookingrange_content_item_from_days, .scwaff_probookingrange_content_item_to_days").slideUp();
				elthis.find(".scwaff_probookingrange_content_item_from_time, .scwaff_probookingrange_content_item_to_time").slideUp();
			}else if(thisVal == "weeks"){
				elthis.find(".scwaff_probookingrange_content_item_from_custom, .scwaff_probookingrange_content_item_to_custom").slideUp();
				elthis.find(".scwaff_probookingrange_content_item_from_months, .scwaff_probookingrange_content_item_to_months").slideUp();
				elthis.find(".scwaff_probookingrange_content_item_from_weeks, .scwaff_probookingrange_content_item_to_weeks").slideDown();
				elthis.find(".scwaff_probookingrange_content_item_from_days, .scwaff_probookingrange_content_item_to_days").slideUp();
				elthis.find(".scwaff_probookingrange_content_item_from_time, .scwaff_probookingrange_content_item_to_time").slideUp();
			}else if(thisVal == "days"){
				elthis.find(".scwaff_probookingrange_content_item_from_custom, .scwaff_probookingrange_content_item_to_custom").slideUp();
				elthis.find(".scwaff_probookingrange_content_item_from_months, .scwaff_probookingrange_content_item_to_months").slideUp();
				elthis.find(".scwaff_probookingrange_content_item_from_weeks, .scwaff_probookingrange_content_item_to_weeks").slideUp();
				elthis.find(".scwaff_probookingrange_content_item_from_days, .scwaff_probookingrange_content_item_to_days").slideDown();
				elthis.find(".scwaff_probookingrange_content_item_from_time, .scwaff_probookingrange_content_item_to_time").slideUp();
			}else{
				elthis.find(".scwaff_probookingrange_content_item_from_custom, .scwaff_probookingrange_content_item_to_custom").slideUp();
				elthis.find(".scwaff_probookingrange_content_item_from_months, .scwaff_probookingrange_content_item_to_months").slideUp();
				elthis.find(".scwaff_probookingrange_content_item_from_weeks, .scwaff_probookingrange_content_item_to_weeks").slideUp();
				elthis.find(".scwaff_probookingrange_content_item_from_days, .scwaff_probookingrange_content_item_to_days").slideUp();
				elthis.find(".scwaff_probookingrange_content_item_from_time, .scwaff_probookingrange_content_item_to_time").slideDown();
			}
		});
		elthis.find(".probookingrange_item_fromcustom, .probookingrange_item_tocustom").datepicker({
			dateFormat : "yy-mm-dd"
		});
	});
	jQuery(".scwaff_probookingrange_add_button").on("click", function(){
		var item = jQuery(".scwaff_probookingrange_content_item:eq(0)").clone();
		jQuery(".scwaff_probookingrange_content").append(item);
		
		jQuery(".scwaff_probookingrange_content_item").each(function(){
			var elthis = jQuery(this);
			elthis.find(".scwaff_probookingrange_content_item_type_select").change(function(){
				var thisVal = jQuery(this).val();
				if(thisVal == "custom"){
					elthis.find(".scwaff_probookingrange_content_item_from_custom, .scwaff_probookingrange_content_item_to_custom").slideDown();
					elthis.find(".scwaff_probookingrange_content_item_from_months, .scwaff_probookingrange_content_item_to_months").slideUp();
					elthis.find(".scwaff_probookingrange_content_item_from_weeks, .scwaff_probookingrange_content_item_to_weeks").slideUp();
					elthis.find(".scwaff_probookingrange_content_item_from_days, .scwaff_probookingrange_content_item_to_days").slideUp();
					elthis.find(".scwaff_probookingrange_content_item_from_time, .scwaff_probookingrange_content_item_to_time").slideUp();
				}else if(thisVal == "months"){
					elthis.find(".scwaff_probookingrange_content_item_from_custom, .scwaff_probookingrange_content_item_to_custom").slideUp();
					elthis.find(".scwaff_probookingrange_content_item_from_months, .scwaff_probookingrange_content_item_to_months").slideDown();
					elthis.find(".scwaff_probookingrange_content_item_from_weeks, .scwaff_probookingrange_content_item_to_weeks").slideUp();
					elthis.find(".scwaff_probookingrange_content_item_from_days, .scwaff_probookingrange_content_item_to_days").slideUp();
					elthis.find(".scwaff_probookingrange_content_item_from_time, .scwaff_probookingrange_content_item_to_time").slideUp();
				}else if(thisVal == "weeks"){
					elthis.find(".scwaff_probookingrange_content_item_from_custom, .scwaff_probookingrange_content_item_to_custom").slideUp();
					elthis.find(".scwaff_probookingrange_content_item_from_months, .scwaff_probookingrange_content_item_to_months").slideUp();
					elthis.find(".scwaff_probookingrange_content_item_from_weeks, .scwaff_probookingrange_content_item_to_weeks").slideDown();
					elthis.find(".scwaff_probookingrange_content_item_from_days, .scwaff_probookingrange_content_item_to_days").slideUp();
					elthis.find(".scwaff_probookingrange_content_item_from_time, .scwaff_probookingrange_content_item_to_time").slideUp();
				}else if(thisVal == "days"){
					elthis.find(".scwaff_probookingrange_content_item_from_custom, .scwaff_probookingrange_content_item_to_custom").slideUp();
					elthis.find(".scwaff_probookingrange_content_item_from_months, .scwaff_probookingrange_content_item_to_months").slideUp();
					elthis.find(".scwaff_probookingrange_content_item_from_weeks, .scwaff_probookingrange_content_item_to_weeks").slideUp();
					elthis.find(".scwaff_probookingrange_content_item_from_days, .scwaff_probookingrange_content_item_to_days").slideDown();
					elthis.find(".scwaff_probookingrange_content_item_from_time, .scwaff_probookingrange_content_item_to_time").slideUp();
				}else{
					elthis.find(".scwaff_probookingrange_content_item_from_custom, .scwaff_probookingrange_content_item_to_custom").slideUp();
					elthis.find(".scwaff_probookingrange_content_item_from_months, .scwaff_probookingrange_content_item_to_months").slideUp();
					elthis.find(".scwaff_probookingrange_content_item_from_weeks, .scwaff_probookingrange_content_item_to_weeks").slideUp();
					elthis.find(".scwaff_probookingrange_content_item_from_days, .scwaff_probookingrange_content_item_to_days").slideUp();
					elthis.find(".scwaff_probookingrange_content_item_from_time, .scwaff_probookingrange_content_item_to_time").slideDown();
				}
			});
			elthis.find(".probookingrange_item_fromcustom, .probookingrange_item_tocustom").removeClass("hasDatepicker");
			elthis.find(".probookingrange_item_fromcustom, .probookingrange_item_tocustom").datepicker({
				dateFormat : "yy-mm-dd"
			});
		});
	});
	
	///////////////////////////
	jQuery(".scwaff_prodata_costrange_add_button").on("click", function(){
		var item = jQuery(".scwaff_prodata_costrange_content_item:eq(0)").clone();
		jQuery(".scwaff_prodata_costrange_content").append(item);
		
		jQuery(".scwaff_prodata_costrange_content_item").each(function(){
			var elthis = jQuery(this);
			
			elthis.find(".scwaff_prodata_costrange_content_item_type_select").change(function(){
				var thisVal = jQuery(this).val();
				if(thisVal == "custom"){
					elthis.find(".scwaff_prodata_costrange_content_item_from_custom, .scwaff_prodata_costrange_content_item_to_custom").slideDown();
					elthis.find(".scwaff_prodata_costrange_content_item_from_months, .scwaff_prodata_costrange_content_item_to_months").slideUp();
					elthis.find(".scwaff_prodata_costrange_content_item_from_weeks, .scwaff_prodata_costrange_content_item_to_weeks").slideUp();
					elthis.find(".scwaff_prodata_costrange_content_item_from_days, .scwaff_prodata_costrange_content_item_to_days").slideUp();
					elthis.find(".scwaff_prodata_costrange_content_item_from_time, .scwaff_prodata_costrange_content_item_to_time").slideUp();
					elthis.find(".scwaff_prodata_costrange_content_item_from_perblock, .scwaff_prodata_costrange_content_item_to_perblock").slideUp();
				}else if(thisVal == "months"){
					elthis.find(".scwaff_prodata_costrange_content_item_from_custom, .scwaff_prodata_costrange_content_item_to_custom").slideUp();
					elthis.find(".scwaff_prodata_costrange_content_item_from_months, .scwaff_prodata_costrange_content_item_to_months").slideDown();
					elthis.find(".scwaff_prodata_costrange_content_item_from_weeks, .scwaff_prodata_costrange_content_item_to_weeks").slideUp();
					elthis.find(".scwaff_prodata_costrange_content_item_from_days, .scwaff_prodata_costrange_content_item_to_days").slideUp();
					elthis.find(".scwaff_prodata_costrange_content_item_from_time, .scwaff_prodata_costrange_content_item_to_time").slideUp();
					elthis.find(".scwaff_prodata_costrange_content_item_from_perblock, .scwaff_prodata_costrange_content_item_to_perblock").slideUp();
				}else if(thisVal == "weeks"){
					elthis.find(".scwaff_prodata_costrange_content_item_from_custom, .scwaff_prodata_costrange_content_item_to_custom").slideUp();
					elthis.find(".scwaff_prodata_costrange_content_item_from_months, .scwaff_prodata_costrange_content_item_to_months").slideUp();
					elthis.find(".scwaff_prodata_costrange_content_item_from_weeks, .scwaff_prodata_costrange_content_item_to_weeks").slideDown();
					elthis.find(".scwaff_prodata_costrange_content_item_from_days, .scwaff_prodata_costrange_content_item_to_days").slideUp();
					elthis.find(".scwaff_prodata_costrange_content_item_from_time, .scwaff_prodata_costrange_content_item_to_time").slideUp();
					elthis.find(".scwaff_prodata_costrange_content_item_from_perblock, .scwaff_prodata_costrange_content_item_to_perblock").slideUp();
				}else if(thisVal == "days"){
					elthis.find(".scwaff_prodata_costrange_content_item_from_custom, .scwaff_prodata_costrange_content_item_to_custom").slideUp();
					elthis.find(".scwaff_prodata_costrange_content_item_from_months, .scwaff_prodata_costrange_content_item_to_months").slideUp();
					elthis.find(".scwaff_prodata_costrange_content_item_from_weeks, .scwaff_prodata_costrange_content_item_to_weeks").slideUp();
					elthis.find(".scwaff_prodata_costrange_content_item_from_days, .scwaff_prodata_costrange_content_item_to_days").slideDown();
					elthis.find(".scwaff_prodata_costrange_content_item_from_time, .scwaff_prodata_costrange_content_item_to_time").slideUp();
					elthis.find(".scwaff_prodata_costrange_content_item_from_perblock, .scwaff_prodata_costrange_content_item_to_perblock").slideUp();
				}else if(thisVal == "persons" || thisVal == "blocks"){
					elthis.find(".scwaff_prodata_costrange_content_item_from_custom, .scwaff_prodata_costrange_content_item_to_custom").slideUp();
					elthis.find(".scwaff_prodata_costrange_content_item_from_months, .scwaff_prodata_costrange_content_item_to_months").slideUp();
					elthis.find(".scwaff_prodata_costrange_content_item_from_weeks, .scwaff_prodata_costrange_content_item_to_weeks").slideUp();
					elthis.find(".scwaff_prodata_costrange_content_item_from_days, .scwaff_prodata_costrange_content_item_to_days").slideUp();
					elthis.find(".scwaff_prodata_costrange_content_item_from_time, .scwaff_prodata_costrange_content_item_to_time").slideUp();
					elthis.find(".scwaff_prodata_costrange_content_item_from_perblock, .scwaff_prodata_costrange_content_item_to_perblock").slideDown();
				}else{
					elthis.find(".scwaff_prodata_costrange_content_item_from_custom, .scwaff_prodata_costrange_content_item_to_custom").slideUp();
					elthis.find(".scwaff_prodata_costrange_content_item_from_months, .scwaff_prodata_costrange_content_item_to_months").slideUp();
					elthis.find(".scwaff_prodata_costrange_content_item_from_weeks, .scwaff_prodata_costrange_content_item_to_weeks").slideUp();
					elthis.find(".scwaff_prodata_costrange_content_item_from_days, .scwaff_prodata_costrange_content_item_to_days").slideUp();
					elthis.find(".scwaff_prodata_costrange_content_item_from_time, .scwaff_prodata_costrange_content_item_to_time").slideDown();
					elthis.find(".scwaff_prodata_costrange_content_item_from_perblock, .scwaff_prodata_costrange_content_item_to_perblock").slideUp();
				}
			});
			elthis.find(".scwaff_proccif_custom, .scwaff_proccit_custom").removeClass("hasDatepicker");
			elthis.find(".scwaff_proccif_custom, .scwaff_proccit_custom").datepicker({
				dateFormat : "yy-mm-dd"
			});
		});
	});
	jQuery(".scwaff_prodata_costrange_content_item").each(function(){
		var elthis = jQuery(this);
		
		elthis.find(".scwaff_prodata_costrange_content_item_type_select").change(function(){
			var thisVal = jQuery(this).val();
			if(thisVal == "custom"){
				elthis.find(".scwaff_prodata_costrange_content_item_from_custom, .scwaff_prodata_costrange_content_item_to_custom").slideDown();
				elthis.find(".scwaff_prodata_costrange_content_item_from_months, .scwaff_prodata_costrange_content_item_to_months").slideUp();
				elthis.find(".scwaff_prodata_costrange_content_item_from_weeks, .scwaff_prodata_costrange_content_item_to_weeks").slideUp();
				elthis.find(".scwaff_prodata_costrange_content_item_from_days, .scwaff_prodata_costrange_content_item_to_days").slideUp();
				elthis.find(".scwaff_prodata_costrange_content_item_from_time, .scwaff_prodata_costrange_content_item_to_time").slideUp();
				elthis.find(".scwaff_prodata_costrange_content_item_from_perblock, .scwaff_prodata_costrange_content_item_to_perblock").slideUp();
			}else if(thisVal == "months"){
				elthis.find(".scwaff_prodata_costrange_content_item_from_custom, .scwaff_prodata_costrange_content_item_to_custom").slideUp();
				elthis.find(".scwaff_prodata_costrange_content_item_from_months, .scwaff_prodata_costrange_content_item_to_months").slideDown();
				elthis.find(".scwaff_prodata_costrange_content_item_from_weeks, .scwaff_prodata_costrange_content_item_to_weeks").slideUp();
				elthis.find(".scwaff_prodata_costrange_content_item_from_days, .scwaff_prodata_costrange_content_item_to_days").slideUp();
				elthis.find(".scwaff_prodata_costrange_content_item_from_time, .scwaff_prodata_costrange_content_item_to_time").slideUp();
				elthis.find(".scwaff_prodata_costrange_content_item_from_perblock, .scwaff_prodata_costrange_content_item_to_perblock").slideUp();
			}else if(thisVal == "weeks"){
				elthis.find(".scwaff_prodata_costrange_content_item_from_custom, .scwaff_prodata_costrange_content_item_to_custom").slideUp();
				elthis.find(".scwaff_prodata_costrange_content_item_from_months, .scwaff_prodata_costrange_content_item_to_months").slideUp();
				elthis.find(".scwaff_prodata_costrange_content_item_from_weeks, .scwaff_prodata_costrange_content_item_to_weeks").slideDown();
				elthis.find(".scwaff_prodata_costrange_content_item_from_days, .scwaff_prodata_costrange_content_item_to_days").slideUp();
				elthis.find(".scwaff_prodata_costrange_content_item_from_time, .scwaff_prodata_costrange_content_item_to_time").slideUp();
				elthis.find(".scwaff_prodata_costrange_content_item_from_perblock, .scwaff_prodata_costrange_content_item_to_perblock").slideUp();
			}else if(thisVal == "days"){
				elthis.find(".scwaff_prodata_costrange_content_item_from_custom, .scwaff_prodata_costrange_content_item_to_custom").slideUp();
				elthis.find(".scwaff_prodata_costrange_content_item_from_months, .scwaff_prodata_costrange_content_item_to_months").slideUp();
				elthis.find(".scwaff_prodata_costrange_content_item_from_weeks, .scwaff_prodata_costrange_content_item_to_weeks").slideUp();
				elthis.find(".scwaff_prodata_costrange_content_item_from_days, .scwaff_prodata_costrange_content_item_to_days").slideDown();
				elthis.find(".scwaff_prodata_costrange_content_item_from_time, .scwaff_prodata_costrange_content_item_to_time").slideUp();
				elthis.find(".scwaff_prodata_costrange_content_item_from_perblock, .scwaff_prodata_costrange_content_item_to_perblock").slideUp();
			}else if(thisVal == "persons" || thisVal == "blocks"){
				elthis.find(".scwaff_prodata_costrange_content_item_from_custom, .scwaff_prodata_costrange_content_item_to_custom").slideUp();
				elthis.find(".scwaff_prodata_costrange_content_item_from_months, .scwaff_prodata_costrange_content_item_to_months").slideUp();
				elthis.find(".scwaff_prodata_costrange_content_item_from_weeks, .scwaff_prodata_costrange_content_item_to_weeks").slideUp();
				elthis.find(".scwaff_prodata_costrange_content_item_from_days, .scwaff_prodata_costrange_content_item_to_days").slideUp();
				elthis.find(".scwaff_prodata_costrange_content_item_from_time, .scwaff_prodata_costrange_content_item_to_time").slideUp();
				elthis.find(".scwaff_prodata_costrange_content_item_from_perblock, .scwaff_prodata_costrange_content_item_to_perblock").slideDown();
			}else{
				elthis.find(".scwaff_prodata_costrange_content_item_from_custom, .scwaff_prodata_costrange_content_item_to_custom").slideUp();
				elthis.find(".scwaff_prodata_costrange_content_item_from_months, .scwaff_prodata_costrange_content_item_to_months").slideUp();
				elthis.find(".scwaff_prodata_costrange_content_item_from_weeks, .scwaff_prodata_costrange_content_item_to_weeks").slideUp();
				elthis.find(".scwaff_prodata_costrange_content_item_from_days, .scwaff_prodata_costrange_content_item_to_days").slideUp();
				elthis.find(".scwaff_prodata_costrange_content_item_from_time, .scwaff_prodata_costrange_content_item_to_time").slideDown();
				elthis.find(".scwaff_prodata_costrange_content_item_from_perblock, .scwaff_prodata_costrange_content_item_to_perblock").slideUp();
			}
		});
		elthis.find(".scwaff_proccif_custom, .scwaff_proccit_custom").removeClass("hasDatepicker");
		elthis.find(".scwaff_proccif_custom, .scwaff_proccit_custom").datepicker({
			dateFormat : "yy-mm-dd"
		});
	});
	
	////////////////////////////
	jQuery(".scwaff_proresources_content_res_item").each(function(){
		var elthis = jQuery(this);
		elthis.find(".scwaff_proresources_crii").change(function(){
			if( jQuery(this).is(":checked") ){
				elthis.children(".scwaff_proresources_content_res_item_basecost").slideDown();
				elthis.children(".scwaff_proresources_content_res_item_blockcost").slideDown();
			}else{
				elthis.children(".scwaff_proresources_content_res_item_basecost").slideUp();
				elthis.children(".scwaff_proresources_content_res_item_blockcost").slideUp();
			}
		});
	});
	
	//////////////////
	var proImageframe;
	jQuery( '.scwaff_images_content_feature_upload > span' ).on( 'click', function( event ) {
		event.preventDefault();
		if ( proImageframe ) {
			proImageframe.open();
			return;
		}
		proImageframe = wp.media.frames.proImageframe = wp.media({
			title: jQuery( this ).data( 'uploader_title' ),
			button: {
				text: jQuery( this ).data( 'uploader_button_text' ),
			}
		});
		proImageframe.on( 'select', function() {
			var attachment = proImageframe.state().get('selection').first().toJSON();
			jQuery( '.scwaff_images_content_feature_preview' ).empty();
			jQuery( '.scwaff_images_content_feature_preview' ).append("<img src='"+attachment.url+"'>");
		});
		proImageframe.open();
	});
	
	var proGalleryImageframe;
	jQuery( '.scwaff_images_content_gallery_upload > span' ).on( 'click', function( event ) {
		event.preventDefault();
		if ( proGalleryImageframe ) {
			proGalleryImageframe.open();
			return;
		}
		proGalleryImageframe = wp.media.frames.proGalleryImageframe = wp.media({
			title: jQuery( this ).data( 'uploader_title' ),
			button: {
				text: jQuery( this ).data( 'uploader_button_text' ),
			},
			multiple: true
		});
		proGalleryImageframe.on( 'select', function() {
			var attachment = proGalleryImageframe.state().get('selection').first().toJSON();
			jQuery( '.scwaff_images_content_gallery_preview' ).append("<div class='scwaff_images_content_gallery_preview_item'>"+
				"<span><img src='"+attachment.url+"'></span>"+
				"<span class='scwaff_images_content_gallery_preview_item_delete'><i class='fas fa-trash-alt'></i></span>"+
			"</div>");
			jQuery(".scwaff_images_content_gallery_preview_item").each(function(){
				var elthis = jQuery(this);
				elthis.find("i").on("click", function(){
					elthis.remove();
				});
			});
		});
		proGalleryImageframe.open();
	});
	
	jQuery("#scwaff_managestock").change(function(){
		if( jQuery(this).is(":checked") ){
			jQuery("#scwaff_stockquantity").removeAttr("disabled");
			jQuery("#scwaff_allowbackorders").removeAttr("disabled");
		}else{
			jQuery("#scwaff_stockquantity").attr("disabled", "disabled");
			jQuery("#scwaff_allowbackorders").attr("disabled", "disabled");
		}
	});
	///////////////////////
	jQuery(".scwaff_submit_button").on("click", function(){
		var proType = jQuery("#scwaff_protype").find(".filter.active").text();
		
		if(proType == "Simple product")
			submitSimple();
		else if(proType == "Grouped product")
			submitGrouped();
		else if(proType == "External/Affiliate product")
			submitExternal();
		else if(proType == "Variable product")
			submitVariable();
		else if(proType == "Bookable product")
			submitBookable();
	});
});