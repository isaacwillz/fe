
jQuery(document).ready(function(){
	"use strict";
	var pluginURL = jQuery(".smartcms_url").val();
	
	jQuery(".smartcms_manageproducts_content_item").each(function(){
		var elthis = jQuery(this);
		elthis.find(".fa-trash-o").on("click", function(){
			var proId = elthis.children(".smartcms_manageproducts_content_item_id").text();
			jQuery.ajax({
				url: pluginURL+"helpers/helper.php",
				data: {
					proId: proId,
					task: "delete_product"
				},
				type: 'POST',
				beforeSend: function(e){
					jQuery(".smartcms_manageproducts").css("opacity", "0.5");
					jQuery(".scwaff_ajax_loading").show();
				},
				success: function(data){
					jQuery(".smartcms_manageproducts").css("opacity", "1");
					jQuery(".scwaff_ajax_loading").hide();
					
					if(data == 1){
						elthis.remove();
					}else
						alert("Error!");
				}
			});
		});
	});
});